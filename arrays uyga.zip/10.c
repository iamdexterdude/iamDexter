#include <stdio.h>

int main() {
    int n,c,l=0, i;
     printf("nechta son kiritasan= ");
    scanf("%d",&i);
    int a[i] ;
    printf("nechini tekshirishni hohlaysan= ");
    scanf("%d",&c);
  
    for (n=0; n<i; n++){
       printf("a[%d]= ",n+1);
       scanf("%d",&a[n]);

    }
   
printf("javob:\n");
  
    
  
    {
        for (int k=0; k<=i; ++k){
             if (a[k]==c){
                l++;
             }
             }
             printf("%d marta",l);
    } 
    return 0;
}