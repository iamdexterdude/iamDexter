#include <stdio.h>

int main() {
    int n;
    int a[] = {6, 25, 91, 23, 72, 9, 18, 6};
    printf("son= ");
    scanf("%d", &n);
     int k=1;
    while (k<8){
        printf("%d  ",a[k]);
        k++;
    }
   printf("%d",n);
    return 0;
}
