#include <stdio.h>

int main() {
    int n, i;
    int a[] = {1, 2, 3, 4, 5, 6, 7, 8};

    printf("indexi= ");
    scanf("%d", &i);

    printf("son= ");
    scanf("%d", &n);

  
    if (i >= 1 && i <= 8) {
        a[i - 1] = n;
    } else {
        printf("Invalid son\n");
        return 1; 
    }

 
    for (int k = 0; k < 8; ++k) {
        printf("%d ", a[k]);
    }
    printf("\n");

    return 0;
}
