#include<stdio.h>
int main(){
    int a[] = {12, 21, 36, 71, 24, 85, 12, 30, 25};
    int s=0,k=1;
    for (int i=0; i<9; ++i){
        s+=a[i];
        k++;
            }
      printf("ortachasi= %d\n",s/k);
     
}