#include <stdio.h>

int main() {
    int n;
    int a[] = {6, 25, 91, 23, 72, 9, 18, 6};
    printf("son= ");
    scanf("%d", &n);

   int k =0;

    for (int i = 0; i < 8; ++i) {
        if (n<=8) {
        printf("J= %d",a[n-1]); break;}
            else printf("0");  break;
        
    }

    return 0;
}
