#include <stdio.h>

int main() {
    int n, i;
    int a[] = {1, 2, 3, 4, 5, 6, 7, 8};

    printf("indexi= ");
    scanf("%d", &i);

    
  
    if (i < 1 || i > 8) {
         printf("Invalid index input bro go learn c agaian and come back, or if just wanna check me , no need to check iam infallable\n");
        
    } else {
        for (int k=0; k<8; ++k){
            if (k==i-1){
                continue;
            }
            else {printf("%d ",a[k]);}
    } 
   printf("\n");

     
    }

 
    
    return 0;
}
