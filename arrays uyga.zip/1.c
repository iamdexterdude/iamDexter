#include<stdio.h>
int main(){
    int a[] = {12, 21, 36, 71, 24, 85, 12, 30, 25};
    int max = a[0];
    int min = a[0];
    for (int i=0; i<8; ++i){
        if (max<a[i]) max=a[i];
        else if ( min > a[i])
        min = a[i];
            }
      printf("max= %d\n",max);
      printf("min= %d",min);

}