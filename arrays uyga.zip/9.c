#include <stdio.h>

int main() {
    int i;
    printf("nechta son kiritasan= ");
    scanf("%d", &i);
    int a[i];

    
    for (int n = 0; n < i; n++) {
        a[n] = 0;
    }

    for (int n = 0; n < i; n++) {
        printf("a[%d]= ", n + 1);
        scanf("%d", &a[n]);
    }

    printf("Teskarisi:\n");
    for (int k = i - 1; k >= 0; --k) {
        printf("%d ", a[k]);
    }
    printf("\n");

    return 0;
}
