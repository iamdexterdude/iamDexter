#include <stdio.h>

int main() {
    int n;
    int a[] = {6, 25, 91, 23, 72, 9, 18, 6};
    scanf("%d", &n);

    int k = 0;  

    for (int i = 0; i < 8; ++i) {
        if (a[i] == n) {
            k = 1; 
            break;  
        }
    }

    if (k) {
        printf("true\n");
    } else {
        printf("yoq\n");
    }

    return 0;
}
